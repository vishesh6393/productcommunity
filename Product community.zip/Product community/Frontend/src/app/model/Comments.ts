export interface Comments{
    commentId:any;
    comment:string;
    userName:string;
    heading:string;
    date:string;
}