export interface Stats{
countPosts:number;
countComments:number;
countUsers:number;
}