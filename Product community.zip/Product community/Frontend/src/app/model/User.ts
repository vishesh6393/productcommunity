export interface User{
emailId:string;
firstName:string;
lastName:string;
password:string;
}
