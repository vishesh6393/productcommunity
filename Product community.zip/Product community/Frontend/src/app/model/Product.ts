export interface Product{
    messageBody:any;
    subject:any;
    question:any;
    userName:any;
    date:any;
    
}